import COMP_SUMMARY 
from chatterbot import ChatBot
from chatterbot.trainers import ChatterBotCorpusTrainer
from chatterbot.conversation import Statement
from flask import Flask, render_template, request
import webbrowser
import openpyxl as op
import pandas as pd
import oracledb as orc

wrkbk1=op.load_workbook("C:\\PYTHON\\COMP_SUMMARY_DETAILS\\SQL_DETAILS.xlsx")
wrksht1=wrkbk1['CONFIG']
app=Flask (__name__)

bot=ChatBot('CompGuru')
trainer=ChatterBotCorpusTrainer(bot)
#trainer.train("chatterbot.corpus.english")
trainer.train('C:\\PYTHON\\Lib\\site-packages\\chatterbot_corpus\\data\\custom\\greetings_modification.yml')

##print("Comp Guru: " + "Hi.. I am Comp Guru...")
##print("Comp Guru: " + "How may I help you??")

@app.route('/', methods =['POST','GET'])
def index():
    if request.method == 'POST':
        frequency=request.form.get('frq')
        payperiodname=request.form.get('prd')
        if frequency == "weeklyfrq":
            payfrequency="WEEKLY"
            wrksht1.cell(row=2, column=6).value=payfrequency
            wrksht1.cell(row=2, column=3).value=payperiodname
        elif frequency == "monthlyfrq":
            payfrequency="MONTHLY"
            wrksht1.cell(row=2, column=6).value=payfrequency
            wrksht1.cell(row=2, column=4).value=payperiodname
        elif frequency == "yearlyfrq":
            payfrequency="YEARLY"
            wrksht1.cell(row=2, column=6).value=payfrequency
            wrksht1.cell(row=2, column=5).value=payperiodname
        environment=request.form.get('envmnt')
        if environment == "sit":
            payenvironment="SIT"
            wrksht1.cell(row=2, column=2).value=payenvironment
        elif environment == "pat":
            payenvironment="PAT"
            wrksht1.cell(row=2, column=2).value=payenvironment
        print (payfrequency)
        print (payenvironment)
        print (payperiodname)
        wrkbk1.save("C:\\PYTHON\\COMP_SUMMARY_DETAILS\\SQL_DETAILS.xlsx")
        COMP_SUMMARY.DeleteAllFiles()
        COMP_SUMMARY.ExecuteResults()
    return render_template('ChatbotUI.html')

@app.route("/get")
def get_bot_response():
    userText=request.args.get('userMessage')
    return str(bot.get_response(userText))

#@app.route("/get")
#def get_frequency_response():
#    Periodfreqency=request.form.getUserResponsefrequency()
#    print (Periodfreqency)
#    return str(Periodfreqency)

#@app.route('/', methods=["GET","POST"])
#def UserFormDetails():
#    if request.method == "POST":
#        payfrequency=request.form.get("frq")
#        return payfrequency
#    return render_template ("ChatbotUI.html")

"""@app.route('/', methods=['POST'])
def userformgetpayfrequencyvalue():
    weeklyfrequency=request.form('weeklyfrq')
    monthlyfrequency=request.form('monthlyfrq')
    yearlyfrequency=request.form('yearlyfrq')
    if weeklyfrequency.upper()=="WEEKLY":
        payfrequency="WEEKLY"
    elif monthlyfrequency.upper()=="MONTHLY":
        payfrequency="MONTHLY"
    elif yearlyfrequency.upper()=="YEARLY":
        payfrequency="YEARLY"
    
    sitenv=request.form('sit')
    patenv=request.form('pat')
    if sitenv.upper()=="SIT":
        payenvironment="WEEKLY"
    elif patenv.upper()=="PAT":
        payenvironment="MONTHLY"

    periodname=request.form('prd')

    return datavalidate(payfrequency,payenvironment,periodname)

def datavalidate(payfrequency,payenvironment,periodname):
    return True"""

## MAIN
if __name__ =="__main__":
    webbrowser.open_new("http://127.0.0.1:5000")
    app.run()
    #form=cgi.FieldStorage()
    #payfrequency=form.getvalue("frq")
    #print (payfrequency)

    