import openpyxl as op
import oracledb as orc
import mysql.connector as sqlcon
import pandas as pd
import plotly_express as ple
import plotly as pl
import os

wrkbk1=op.load_workbook("C:\\PYTHON\\COMP_SUMMARY_DETAILS\\SQL_DETAILS.xlsx")
wrksht1=wrkbk1['CONFIG']
wrksht2=wrkbk1['SQL_CONN']
wrksht3=wrkbk1['SQL_QUERY']
path="C:\\PYTHON\\COMP_SUMMARY_DETAILS\\RESULTS\\"
detailresultWeeklywrkbkname=path+"SQL_DETAIL_WEEK_RESULTS.xlsx"
Weeklyresultwrkbkname=path+"SQL_WEEK_RESULTS.xlsx"
detailresultMonthlywrkbkname=path+"SQL_DETAIL_MONTH_RESULTS.xlsx"
Monthlyresultwrkbkname=path+"SQL_MONTH_RESULTS.xlsx"
detailresultYearlywrkbkname=path+"SQL_DETAIL_YEAR_RESULTS.xlsx"
Yearlyresultwrkbkname=path+"SQL_YEAR_RESULTS.xlsx"

def DeleteAllFiles():
    for f in os.listdir(path):
        os.remove(os.path.join(path,f))

## WEEKLY
def Weekly_Payment_EarnCode_Query_Run():
    try:
        totalrow=wrksht2.max_row
        for a in range(2,totalrow):
            userenvvalue=wrksht1.cell(row=2, column=2).value
            envvalue=wrksht2.cell(row=a, column=1).value
            if (envvalue==userenvvalue):
                databasehostname=wrksht2.cell(row=a, column=2).value
                databaseportno=wrksht2.cell(row=a, column=3).value
                databasesid=wrksht2.cell(row=a, column=4).value
                databaseusrname=wrksht2.cell(row=2, column=5).value
                databasepaswrd=wrksht2.cell(row=2, column=6).value
                break
        
        dbconn = orc.connect(user=str(databaseusrname), password=str(databasepaswrd), host=str(databasehostname), port=str(databaseportno), sid=str(databasesid))
        #dbconn=sqlcon.connect(host=str(databasehostname), port=str(databaseportno), sid=str(databasesid), user=str(databaseusrname), password=str(databasepaswrd))
        userperiod=wrksht1.cell(row=2, column=3).value
        Tempquerydetails=wrksht3.cell(row=2, column=3).value
        Finalquerydetails=Tempquerydetails.replace("PeriodType", userperiod)
        workbook = op.Workbook()
        worksheet = workbook.active
        cur=dbconn.cursor()
        cur.execute(Finalquerydetails)
        results = cur.fetchall()
        
        headers = ["PAYEEID", "EARNINGCODEID", "TOTAL COMMISSION"]
        for col, header in enumerate(headers, start=1):
            cell = worksheet.cell(row=1, column=col)
            cell.value = header
            cell.font = op.styles.Font(bold=True)
            cell.alignment = op.styles.Alignment(horizontal="center")
        
        for row, record in enumerate(results, start=2):
            for col, value in enumerate(record, start=1):
                cell = worksheet.cell(row=row, column=col)
                cell.value = value
        
        workbook.save(detailresultWeeklywrkbkname)
        workbook.Dispose()

        dbconn.close()
        #book = op.Workbook()
        #sheet = book.active
        
    except Exception as e:
        print("Please Wait I am on it ..")
        
def Weekly_Payment_Query_Run():
    try:
        totalrow=wrksht2.max_row
        for a in range(2,totalrow):
            userenvvalue=wrksht1.cell(row=2, column=2).value
            envvalue=wrksht2.cell(row=a, column=1).value
            if (envvalue==userenvvalue):
                databasehostname=wrksht2.cell(row=a, column=2).value
                databaseportno=wrksht2.cell(row=a, column=3).value
                databasesid=wrksht2.cell(row=a, column=4).value
                databaseusrname=wrksht2.cell(row=2, column=5).value
                databasepaswrd=wrksht2.cell(row=2, column=6).value
                break
        
        dbconn = orc.connect(user=str(databaseusrname), password=str(databasepaswrd), host=str(databasehostname), port=str(databaseportno), sid=str(databasesid))
        userperiod=wrksht1.cell(row=2, column=3).value
        Tempquerydetails=wrksht3.cell(row=3, column=3).value
        Finalquerydetails=Tempquerydetails.replace("PeriodType", userperiod)
        workbook = op.Workbook()
        worksheet = workbook.active
        cur=dbconn.cursor()
        cur.execute(Finalquerydetails)
        results = cur.fetchall()
        
        headers = ["PAYEEID", "TOTAL COMMISSION"]
        for col, header in enumerate(headers, start=1):
            cell = worksheet.cell(row=1, column=col)
            cell.value = header
            cell.font = op.styles.Font(bold=True)
            cell.alignment = op.styles.Alignment(horizontal="center")
        
        for row, record in enumerate(results, start=2):
            for col, value in enumerate(record, start=1):
                cell = worksheet.cell(row=row, column=col)
                cell.value = value
        
        workbook.save(Weeklyresultwrkbkname)
        workbook.Dispose()
        
        dbconn.close()

    except Exception as e:
         print("Please Wait I am on it ..")

def Weekly_TotalPaymentEarningCodeGraphCreation():
    #plt.style.use('bmh')
    readdata=pd.read_excel(path+"SQL_DETAIL_WEEK_RESULTS.xlsx")
    earningcode=readdata['EARNINGCODEID']
    totalcomp=readdata['TOTAL COMMISSION']
    fig=ple.pie(readdata,values=totalcomp,names=earningcode, title="WEEKLY SURVEY RESULTS-EACH EARNINGCODE")
    fig.update_traces(textposition='inside', textinfo='percent+label')
    fig.update_layout(title_font_size=42)
    pl.offline.plot(fig,filename=path+'Piechart_Weekly_Detail.html')
    #plt.ylabel('EARNINGCODEID', fontsize=4)
    #plt.xlabel('TOTAL COMMISSION', fontsize=4)
    #plt.bar(totalcomp, earningcode)
    #plt.show()

def Weekly_TotalPaymentPayeeGraphCreation():
    #plt.style.use('bmh')
    readdata=pd.read_excel(path+"SQL_WEEK_RESULTS.xlsx")
    payeeid=readdata['PAYEEID']
    totalcomp=readdata['TOTAL COMMISSION']
    fig=ple.pie(readdata,values=totalcomp,names=payeeid, title="WEEKLY SURVEY RESULTS-EACH PAYEEID")
    fig.update_traces(textposition='inside', textinfo='percent+label')
    fig.update_layout(title_font_size=42)
    pl.offline.plot(fig,filename=path+'Piechart_Weekly.html')
    #plt.ylabel('PAYEEID', fontsize=4)
    #plt.xlabel('TOTAL COMMISSION', fontsize=4)
    #plt.bar(totalcomp,payeeid)
    #plt.show()

### MONTHLY
def Monthly_Payment_EarnCode_Query_Run():
    try:
        totalrow=wrksht2.max_row
        for a in range(2,totalrow):
            userenvvalue=wrksht1.cell(row=2, column=2).value
            envvalue=wrksht2.cell(row=a, column=1).value
            if (envvalue==userenvvalue):
                databasehostname=wrksht2.cell(row=a, column=2).value
                databaseportno=wrksht2.cell(row=a, column=3).value
                databasesid=wrksht2.cell(row=a, column=4).value
                databaseusrname=wrksht2.cell(row=2, column=5).value
                databasepaswrd=wrksht2.cell(row=2, column=6).value
                break
        
        dbconn = orc.connect(user=str(databaseusrname), password=str(databasepaswrd), host=str(databasehostname), port=str(databaseportno), sid=str(databasesid))
        userperiod=wrksht1.cell(row=2, column=4).value
        Tempquerydetails=wrksht3.cell(row=4, column=3).value
        Finalquerydetails=Tempquerydetails.replace("PeriodType", userperiod)
        workbook = op.Workbook()
        worksheet = workbook.active
        cur=dbconn.cursor()
        cur.execute(Finalquerydetails)
        results = cur.fetchall()
        
        headers = ["PAYEEID", "EARNINGCODEID", "TOTAL COMMISSION"]
        for col, header in enumerate(headers, start=1):
            cell = worksheet.cell(row=1, column=col)
            cell.value = header
            cell.font = op.styles.Font(bold=True)
            cell.alignment = op.styles.Alignment(horizontal="center")
        
        for row, record in enumerate(results, start=2):
            for col, value in enumerate(record, start=1):
                cell = worksheet.cell(row=row, column=col)
                cell.value = value
        
        workbook.save(detailresultMonthlywrkbkname)
        workbook.Dispose()

        dbconn.close()
    except Exception as e:
         print("Please Wait I am on it ..")
        
def Monthly_Payment_Query_Run():
    try:
        totalrow=wrksht2.max_row
        for a in range(2,totalrow):
            userenvvalue=wrksht1.cell(row=2, column=2).value
            envvalue=wrksht2.cell(row=a, column=1).value
            if (envvalue==userenvvalue):
                databasehostname=wrksht2.cell(row=a, column=2).value
                databaseportno=wrksht2.cell(row=a, column=3).value
                databasesid=wrksht2.cell(row=a, column=4).value
                databaseusrname=wrksht2.cell(row=2, column=5).value
                databasepaswrd=wrksht2.cell(row=2, column=6).value
                break
        
        dbconn = orc.connect(user=str(databaseusrname), password=str(databasepaswrd), host=str(databasehostname), port=str(databaseportno), sid=str(databasesid))
        userperiod=wrksht1.cell(row=2, column=3).value
        Tempquerydetails=wrksht3.cell(row=5, column=3).value
        Finalquerydetails=Tempquerydetails.replace("PeriodType", userperiod)
        workbook = op.Workbook()
        worksheet = workbook.active
        cur=dbconn.cursor()
        cur.execute(Finalquerydetails)
        results = cur.fetchall()
        
        headers = ["PAYEEID", "TOTAL COMMISSION"]
        for col, header in enumerate(headers, start=1):
            cell = worksheet.cell(row=1, column=col)
            cell.value = header
            cell.font = op.styles.Font(bold=True)
            cell.alignment = op.styles.Alignment(horizontal="center")
        
        for row, record in enumerate(results, start=2):
            for col, value in enumerate(record, start=1):
                cell = worksheet.cell(row=row, column=col)
                cell.value = value
        
        workbook.save(Monthlyresultwrkbkname)
        workbook.Dispose()
        
        dbconn.close()
    except Exception as e:
         print("Please Wait I am on it ..")

def Monthly_TotalPaymentEarningCodeGraphCreation():
    readdata=pd.read_excel(path+"SQL_DETAIL_MONTH_RESULTS.xlsx")
    earningcode=readdata['EARNINGCODEID']
    totalcomp=readdata['TOTAL COMMISSION']
    fig=ple.pie(readdata,values=totalcomp,names=earningcode, title="MONTHLY SURVEY RESULTS-EACH EARNINGCODE")
    fig.update_traces(textposition='inside', textinfo='percent+label')
    fig.update_layout(title_font_size=42)
    pl.offline.plot(fig,filename=path+'Piechart_Monthly_Detail.html')

def Monthly_TotalPaymentPayeeGraphCreation():
    readdata=pd.read_excel(path+"SQL_MONTH_RESULTS.xlsx")
    payeeid=readdata['PAYEEID']
    totalcomp=readdata['TOTAL COMMISSION']
    fig=ple.pie(readdata,values=totalcomp,names=payeeid, title="MONTHLY SURVEY RESULTS-EACH PAYEEID")
    fig.update_traces(textposition='inside', textinfo='percent+label')
    fig.update_layout(title_font_size=42)
    pl.offline.plot(fig,filename=path+'Piechart_Monthly.html')

### YEARLY
def Yearly_Payment_EarnCode_Query_Run():
    try:
        totalrow=wrksht2.max_row
        for a in range(2,totalrow):
            userenvvalue=wrksht1.cell(row=2, column=2).value
            envvalue=wrksht2.cell(row=a, column=1).value
            if (envvalue==userenvvalue):
                databasehostname=wrksht2.cell(row=a, column=2).value
                databaseportno=wrksht2.cell(row=a, column=3).value
                databasesid=wrksht2.cell(row=a, column=4).value
                databaseusrname=wrksht2.cell(row=2, column=5).value
                databasepaswrd=wrksht2.cell(row=2, column=6).value
                break
        
        dbconn = orc.connect(user=str(databaseusrname), password=str(databasepaswrd), host=str(databasehostname), port=str(databaseportno), sid=str(databasesid))
        userperiod=wrksht1.cell(row=2, column=5).value
        Tempquerydetails=wrksht3.cell(row=6, column=3).value
        Finalquerydetails=Tempquerydetails.replace("YEAR", userperiod)
        workbook = op.Workbook()
        worksheet = workbook.active
        cur=dbconn.cursor()
        cur.execute(Finalquerydetails)
        results = cur.fetchall()
        
        headers = ["PAYEEID", "EARNINGCODEID", "TOTAL COMMISSION"]
        for col, header in enumerate(headers, start=1):
            cell = worksheet.cell(row=1, column=col)
            cell.value = header
            cell.font = op.styles.Font(bold=True)
            cell.alignment = op.styles.Alignment(horizontal="center")
        
        for row, record in enumerate(results, start=2):
            for col, value in enumerate(record, start=1):
                cell = worksheet.cell(row=row, column=col)
                cell.value = value
        
        workbook.save(detailresultYearlywrkbkname)
        workbook.Dispose()

        dbconn.close()
    except Exception as e:
        print("Please Wait I am on it ..")
        
def Yearly_Payment_Query_Run():
    try:
        totalrow=wrksht2.max_row
        for a in range(2,totalrow):
            userenvvalue=wrksht1.cell(row=2, column=2).value
            envvalue=wrksht2.cell(row=a, column=1).value
            if (envvalue==userenvvalue):
                databasehostname=wrksht2.cell(row=a, column=2).value
                databaseportno=wrksht2.cell(row=a, column=3).value
                databasesid=wrksht2.cell(row=a, column=4).value
                databaseusrname=wrksht2.cell(row=2, column=5).value
                databasepaswrd=wrksht2.cell(row=2, column=6).value
                break
        
        dbconn = orc.connect(user=str(databaseusrname), password=str(databasepaswrd), host=str(databasehostname), port=str(databaseportno), sid=str(databasesid))
        userperiod=wrksht1.cell(row=2, column=5).value
        Tempquerydetails=wrksht3.cell(row=7, column=3).value
        Finalquerydetails=Tempquerydetails.replace("YEAR", userperiod)
        workbook = op.Workbook()
        worksheet = workbook.active
        cur=dbconn.cursor()
        cur.execute(Finalquerydetails)
        results = cur.fetchall()
        
        headers = ["PAYEEID", "TOTAL COMMISSION"]
        for col, header in enumerate(headers, start=1):
            cell = worksheet.cell(row=1, column=col)
            cell.value = header
            cell.font = op.styles.Font(bold=True)
            cell.alignment = op.styles.Alignment(horizontal="center")
        
        for row, record in enumerate(results, start=2):
            for col, value in enumerate(record, start=1):
                cell = worksheet.cell(row=row, column=col)
                cell.value = value
        
        workbook.save(Yearlyresultwrkbkname)
        workbook.Dispose()
        
        dbconn.close()
    except Exception as e:
        print("Please Wait I am on it ..")

def Yearly_TotalPaymentEarningCodeGraphCreation():
    readdata=pd.read_excel(path+"SQL_DETAIL_YEAR_RESULTS.xlsx")
    earningcode=readdata['EARNINGCODEID']
    totalcomp=readdata['TOTAL COMMISSION']
    fig=ple.pie(readdata,values=totalcomp,names=earningcode, title="YEARLY SURVEY RESULTS-EACH EARNINGCODE")
    fig.update_traces(textposition='inside', textinfo='percent+label')
    fig.update_layout(title_font_size=42)
    pl.offline.plot(fig,filename=path+'Piechart_Yearly_Detail.html')

def Yearly_TotalPaymentPayeeGraphCreation():
    readdata=pd.read_excel(path+"SQL_YEAR_RESULTS.xlsx")
    payeeid=readdata['PAYEEID']
    totalcomp=readdata['TOTAL COMMISSION']
    fig=ple.pie(readdata,values=totalcomp,names=payeeid, title="YEARLY SURVEY RESULTS-EACH PAYEEID")
    fig.update_traces(textposition='inside', textinfo='percent+label')
    fig.update_layout(title_font_size=42)
    pl.offline.plot(fig,filename=path+'Piechart_Yearly.html')

def ExecuteResults():
    Payfrq=wrksht1.cell(row=2, column=6).value
    if Payfrq.upper()=="WEEKLY":
        Weekly_Payment_EarnCode_Query_Run()
        Weekly_Payment_Query_Run()
        Weekly_TotalPaymentEarningCodeGraphCreation()
        Weekly_TotalPaymentPayeeGraphCreation()
    elif Payfrq.upper()=="MONTHLY":
        Monthly_Payment_EarnCode_Query_Run()
        Monthly_Payment_Query_Run()
        Monthly_TotalPaymentEarningCodeGraphCreation()
        Monthly_TotalPaymentPayeeGraphCreation()
    elif Payfrq.upper()=="YEARLY":
        Yearly_Payment_EarnCode_Query_Run()
        Yearly_Payment_Query_Run()
        Yearly_TotalPaymentEarningCodeGraphCreation()
        Yearly_TotalPaymentPayeeGraphCreation()

"""def UserInput():
    SummaryTypeUsrInput=""
    SummaryTypeUsrInput=input()
    FinalSummaryTypeUsrInput=SummaryTypeUsrInput.upper()
    print("User want: " + FinalSummaryTypeUsrInput)
    wrksht1=wrkbk1['CONFIG']
    if FinalSummaryTypeUsrInput.find("WEEKLY") != -1 and FinalSummaryTypeUsrInput.find("PAYMENT") != -1:
        EnvUsrInput=input("Please Enter The Environment (Format: ENV): \n")
        wrksht1.cell(row=2, column=2).value=EnvUsrInput.upper()
        PeriodUsrInput=input("Please Enter The Period (Format: Mmm YY Week X): \n")
        wrksht1.cell(row=2, column=3).value=PeriodUsrInput
        PaytypeUsrInput=input("Please Enter The Pay Frequency: \n")
        wrksht1.cell(row=2, column=6).value=PaytypeUsrInput.upper()
        print("Please Wait..")
        ExecuteResults()
        print("Data has been extracted..Thank you for reaching")
    elif FinalSummaryTypeUsrInput.find("MONTHLY") != -1 and FinalSummaryTypeUsrInput.find("PAYMENT") != -1:
        EnvUsrInput=input("Please Enter The Environment: \n")
        wrksht1.cell(row=2, column=2).value=EnvUsrInput.upper()
        PeriodUsrInput=input("Please Enter The Period (Format: Month YYYY): \n")
        wrksht1.cell(row=2, column=4).value=PeriodUsrInput
        PaytypeUsrInput=input("Please Enter The Pay Frequency: \n")
        wrksht1.cell(row=2, column=6).value=PaytypeUsrInput.upper()
        print("Please Wait..")
        ExecuteResults()
        print("Data has been extracted..Thank you for reaching")
    elif FinalSummaryTypeUsrInput.find("YEARLY") != -1 and FinalSummaryTypeUsrInput.find("PAYMENT") != -1:
        EnvUsrInput=input("Please Enter The Environment: \n")
        wrksht1.cell(row=2, column=2).value=EnvUsrInput.upper()
        PeriodUsrInput=input("Please Enter The Period (Format: YYYY): \n")
        wrksht1.cell(row=2, column=5).value=PeriodUsrInput
        PaytypeUsrInput=input("Please Enter The Pay Frequency: \n")
        wrksht1.cell(row=2, column=6).value=PaytypeUsrInput.upper()
        print("Please Wait..")
        ExecuteResults()
        print("Data has been extracted..Thank you for reaching")
    else:
        print("Thank you for reaching")
    wrkbk1.save("C:\\PYTHON\\COMP_SUMMARY_DETAILS\\SQL_DETAILS.xlsx")"""

## MAIN
#if __name__ =="__main__":
#    print("Hi Buddy !! ..")
#    print("This is Comp Guru ..")
#    print("How may i help you?")
    #DeleteAllFiles()
    #UserInput()