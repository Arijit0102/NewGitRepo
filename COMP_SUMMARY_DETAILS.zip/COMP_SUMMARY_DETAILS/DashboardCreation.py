import openpyxl as op
import pandas as pd
import plotly_express as ple
import plotly as pl
import streamlit as st

path="C:\\PYTHON\\COMP_SUMMARY_DETAILS\\RESULTS\\"
readdata=pd.read_excel(path+"SQL_WEEK_RESULTS.xlsx")
wrksht1=wrkbk1['CONFIG']