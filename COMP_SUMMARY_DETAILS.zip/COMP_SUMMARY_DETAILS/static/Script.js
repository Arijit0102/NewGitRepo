const Chatinput=document.querySelector("#textInput");
const SendChatButton=document.querySelector(".buttonInput");

let userMessage;

SendChatButton.addEventListener("click", handleChat);

function myFunction() {
    userMessage=Chatinput.value.trim();
    console.log(userMessage);
}


